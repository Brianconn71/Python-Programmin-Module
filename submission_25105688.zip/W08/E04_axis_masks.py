"""Drill. Boolean masks, and doing the sum along one axis.

Run the tests:

    python -m doctest W08/E04_axis_masks.py

No output means every test passed.

Two ideas, both from the lecture. Comparing an array to a number gives an
array of True and False, which you can count with sum or use as an index.
And every summarising method takes an axis: axis=0 goes down the columns,
axis=1 goes along the rows.

Each function below should be one line of Numpy, with no loop.
"""
import numpy as np
# Needed to add this line as was having issues with numpy versions
# I had numpy 2.5 installed, newer numpy does not need np.int64(1)
np.set_printoptions(legacy="1.25")


def count_above(x, t):
    """Count how many entries of x are greater than t.

    >>> x = np.array([1, 5, 3, 9, 2])
    >>> count_above(x, 2)
    3
    >>> count_above(x, 100)
    0
    """
    # Compare the values in the np array x to the value t and check if the value in the array is greater than t
    # works as another way of looping like in python
    compareEntries = x > t
    # compareEntries will be a numpy array of boolean values or 1s and 0s and we need to return the sum of the true or 1 values
    return compareEntries.sum()


def values_above(x, t):
    """Return just the entries of x greater than t, in their original order.

    >>> x = np.array([1, 5, 3, 9, 2])
    >>> values_above(x, 2)
    array([5, 3, 9])
    >>> values_above(x, 4)
    array([5, 9])
    """
    # Compare the values in the np array x to the value t and check if the value in the array is greater than t
    # works as another way of looping like in python
    compareEntries = x > t
    # compareEntries will return an array of boolean values which we can then use as a mask on the original afrray and return the values that were set as true
    # keeps entires in original array marked as true and removes those marked as false
    # we then return this to the user.
    return x[compareEntries]



def column_means(X):
    """Return the mean of each column of the 2-D array X.

    >>> X = np.array([[1.0, 2.0, 3.0], [3.0, 4.0, 9.0]])
    >>> column_means(X)
    array([2., 3., 6.])
    >>> column_means(np.array([[10.0, 20.0]]))
    array([10., 20.])
    """
    # using the numpy mean functionality on the input X array with axis=0 (columns) - squeezes down rows to leave one value per column
    # in order to return the mean of each column
    return X.mean(axis=0)
    


def row_maxes(X):
    """Return the largest value in each row of the 2-D array X.

    >>> X = np.array([[1.0, 2.0, 3.0], [9.0, 4.0, 0.0]])
    >>> row_maxes(X)
    array([3., 9.])
    >>> row_maxes(np.array([[-1.0, -5.0]]))
    array([-1.])
    """
    # using the numpy max functionality on the input X array with axis=1 (rows)  - squeezes down columns to leave one value per row
    # in order to return the max of each row
    return X.max(axis=1)

if __name__ == "__main__":
    x = np.array([1, 5, 3, 9, 2])
    count_above(x, 2)
    values_above(x, 2)
    X = np.array([[1.0, 2.0, 3.0], [3.0, 4.0, 9.0]])
    column_means(X)