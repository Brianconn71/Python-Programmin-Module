"""Drill. Nothing to write here: the only job is to run this file.

This is Newton's algorithm from the lecture, complete. Run its tests:

    python -m doctest W01/E01_newton.py

No output means every test passed. That silence is the whole point: doctest
only speaks up when something is wrong.

Now make it speak. Change the 1.414214 below to 1.5, run it again, and read
what it prints -- expected, got, and the line it came from. Then change it
back. That is the output you will be reading all semester.
"""


def newton_sqrt(x, tol=1e-10):
    """Return the square root of x.

    Start from a guess, and repeatedly average it with x divided by it. One
    of those two is too small and the other too large, so their average is
    closer than at least one of them.

    >>> round(newton_sqrt(2), 6)
    1.414214
    >>> round(newton_sqrt(16), 6)
    4.0
    >>> newton_sqrt(0)
    0.0
    >>> round(newton_sqrt(73.7), 6)
    8.58487
    """
    # if the number is 0 ten return 0 as a float 0.0
    if x == 0:
        return 0.0
    # Guess turned into a float
    guess = float(x)
    while True:
        # averaging if guess is too big and x / guess is too small. Root is between them.
        guess = (guess + x / guess) / 2
        # checks how far away the guess is from x. tol = tolerance, once smaller than tolerance guess is good.
        if abs(guess * guess - x) < tol:
            # we can now break the loop
            break
    # return the guess.
    return guess
